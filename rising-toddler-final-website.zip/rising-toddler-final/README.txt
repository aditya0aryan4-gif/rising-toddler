RISING TODDLER PLAY SCHOOL — WEBSITE PREVIEW

1. Extract ZIP.
2. Open index.html in Chrome.
3. Edit index.html for text, style.css for design, script.js for navigation.
4. Phone: +91 84594 28145; address from user. School timing deliberately variable.
5. Gallery uses placeholders: classroom images featuring children are NOT included because permission for public use has not been confirmed. Get school and parent/guardian permission before adding them.
6. All 20 facility claims are user-provided and should be verified before publication.
7. Admission button calls the school; no backend or data-collecting form.
8. Google Maps link is an area search, not a verified school pin.
9. Google Fonts require internet; fallback fonts work offline.
10. This is a preview, not an official published site. Obtain school approval before publishing.
